export const Defaults: any = {
  //DEMO API
  //"api" : "http://localhost:5555",
  "api": "http://api.suscopts.org",
  "basic": "<GET FROM PRIEST>",
  // if needed
  "churchid": 0,
  // if needed
  "groupid": 0
}
